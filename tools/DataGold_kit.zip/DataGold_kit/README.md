# DataGold Kit — Goldbach + OWID Macro Pairing

**Purpose**: Drop this folder into your existing repo. Your agent should unzip, read this README, clarify ambiguities, then build the solution using these files **and your existing Goldbach data**.

## What this kit provides
- **OWID ingestion** via `sources.py` with simple caching.
- **Feature engineering** via `features.py` (YoY %, z-scores, monthly resampling).
- **Goldbach-style pairing** via `signals.py` to form a macro **Risk-On/Off** regime.
- **Backtest utilities** via `backtest.py` and simple **risk** helpers in `risk.py`.
- **Streamlit dashboard** to visualize features, pairs, regime, and backtest metrics.
- **Copilot-friendly structure**: short, pure functions with clear signatures.

## Quickstart (human or agent)
1. **Install** (inside your project environment):
   ```bash
   python -m pip install -U pandas numpy httpx pydantic pyyaml polars rich ta scipy streamlit
   ```
2. **Configure**: Edit `datagold/config.yaml` with your chosen OWID grapher IDs and aliases.
3. **Integrate your Goldbach data**:
   - Place your existing series (CSV/Parquet) under `data/processed/` or point to them in code.
   - Ensure a tidy format with columns: `date` (ISO), feature columns (e.g., `gdp_pc`, `energy_yoy`), or provide files that `features.build_feature_matrix()` can read.
4. **Run sanity check**:
   ```bash
   python -m datagold.sources --ping
   python -m datagold.features --demo
   streamlit run datagold/dashboards/streamlit_app.py
   ```

## Agent Task Plan (authoritative)
**Goal**: Use OWID + existing Goldbach data to compute macro regimes and drive swing/day trading logic.

### Phase 0 — Read & Clarify
- Read this README and `datagold/config.yaml`.
- Inventory user repo for Goldbach data sources (CSV/Parquet/DB). Document paths.
- **Ask clarifying questions only if needed**. Use the template below.

**Ambiguity Template**
- Data location ambiguity:
  - *Observed*: e.g., multiple `data/processed` files with similar names.
  - *Decision needed*: Exact file to treat as truth source.
- ID ambiguity:
  - *Observed*: OWID series id in config not present / returns 404.
  - *Decision needed*: Replacement id or disable feature.
- Alignment ambiguity:
  - *Observed*: Feature frequency mismatch (daily/intraday vs monthly).
  - *Decision needed*: Resampling rule (ffill, bfill, interpolate).
- Backtest scope:
  - *Observed*: Multiple markets present.
  - *Decision needed*: Benchmarks (SPY, QQQ, BTC) and date range.

### Phase 1 — Build Data Layer
- Use `datagold/sources.py` to fetch & cache OWID series listed in `config.yaml`.
- Load user's Goldbach feature data (if present) and merge with OWID features via `features.build_feature_matrix`.
- Persist merged feature matrix to `data/processed/features.parquet`.

### Phase 2 — Signals & Regime
- Compute discrete Goldbach scores and select the best low-correlation pair daily via `signals.goldbach_pair_score`.
- Produce `regime.parquet` with columns: `date`, `pair`, `score`, `risk_on` (bool).

### Phase 3 — Backtest & Dashboard
- Backtest overlay using `backtest.vector_backtest` on provided market price series (user repo path).
- Launch Streamlit app for visual validation. Export metrics to `data/processed/metrics.json`.

### Phase 4 — Handoff
- Create `REPORT.md` summarizing: data sources, chosen pairs, thresholds, metrics, and known limitations.
- Provide a list of TODOs for future iteration.

## Minimal Config (`datagold/config.yaml`)
See file. Replace series IDs with the exact OWID grapher IDs you prefer.

## Expected Inputs from Existing Repo
- Goldbach data files or DB credentials.
- Market price history for SPY/QQQ/BTC (CSV or a loader function).
- (Optional) Intraday data for day-trading overlays.

## Outputs
- `data/processed/features.parquet`
- `data/processed/regime.parquet`
- `data/processed/metrics.json`
- Streamlit interactive dashboard.

---

*Timestamp: 2025-09-06T21:12:51.810193*
