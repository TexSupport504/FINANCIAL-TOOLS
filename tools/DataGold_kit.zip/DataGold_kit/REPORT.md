# REPORT.md (to be filled by agent at Phase 4)
- Data sources inventoried
- Feature set chosen (OWID + repo Goldbach)
- Pairing/thresholds
- Backtest metrics
- Known limitations and next steps
