from __future__ import annotations
import pandas as pd, numpy as np

def vector_backtest(prices: pd.Series, entry: pd.Series, exit_: pd.Series | None = None, stop_atr: pd.Series | None = None, risk_free: float = 0.0):
    px = prices.dropna().copy()
    sig = entry.reindex(px.index).fillna(False)
    if exit_ is None: exit_ = ~sig
    ex = exit_.reindex(px.index).fillna(False)
    # Positions: simple long/flat
    pos = sig.astype(int)
    pos = pos.where(~ex, 0)
    # Returns
    ret = px.pct_change().fillna(0.0)
    eq = (1 + ret*pos.shift(1).fillna(0)).cumprod()
    # Metrics
    dd = (eq/eq.cummax()-1).min()
    ann = (eq.iloc[-1])**(252/len(eq)) - 1 if len(eq)>10 else np.nan
    vol = ret.std()*np.sqrt(252)
    sharpe = ((ret.mean()*252) - risk_free) / (vol if vol else np.nan)
    metrics = {
        "CAGR": ann, "MaxDrawdown": dd, "Sharpe": sharpe, "LastEquity": float(eq.iloc[-1])
    }
    return {"equity_curve": eq, "metrics": metrics}
