import streamlit as st
import yaml, pandas as pd
from datagold.sources import merge_series
from datagold.features import build_feature_matrix
from datagold.signals import goldbach_pair_score, regime_series

st.title("DataGold — Goldbach + Macro (OWID)")

cfg_path = "datagold/config.yaml"
cfg = yaml.safe_load(open(cfg_path))
country = st.text_input("Country (e.g., World, United States)", "World")

raw = merge_series(cfg, countries=[country])
feat = build_feature_matrix(raw, cfg, country=country)
st.write("Feature snapshot", feat.tail())

pairs = goldbach_pair_score(feat)
regime = regime_series(pairs)
st.line_chart(pairs['score'])
st.line_chart(regime.astype(int))
st.write("Active pair (last):", pairs.tail(1)['pair'].item())
