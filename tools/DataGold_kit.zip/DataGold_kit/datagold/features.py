from __future__ import annotations
import pandas as pd, numpy as np, yaml
from pathlib import Path

def pct_change_yoy(df: pd.DataFrame) -> pd.DataFrame:
    return df.assign(value=lambda x: x['value'].pct_change(12)*100)

def zscore(df: pd.DataFrame, win: int = 36) -> pd.DataFrame:
    roll = df['value'].rolling(win, min_periods=max(3, win//3))
    return df.assign(value=(df['value'] - roll.mean())/roll.std())

def resample_to_monthly(df: pd.DataFrame, method: str = "ffill") -> pd.DataFrame:
    g = []
    for ent, gdf in df.groupby('entity'):
        m = gdf.set_index('date').resample('MS').agg({'value':'last'})
        if method == "ffill": m = m.ffill()
        elif method == "bfill": m = m.bfill()
        m = m.assign(entity=ent).reset_index()
        g.append(m)
    return pd.concat(g, ignore_index=True)

def apply_transform(df: pd.DataFrame, transform: str) -> pd.DataFrame:
    if transform == "yoy_pct": return pct_change_yoy(df)
    if transform.startswith("zscore"): return zscore(df)
    return df

def build_feature_matrix(raw: dict[str, pd.DataFrame], config: dict, country: str | None = None) -> pd.DataFrame:
    frames = []
    for alias, df in raw.items():
        if country: df = df[df['entity']==country]
        dfm = resample_to_monthly(df)
        transform = next((s['transform'] for s in config['series'] if s['alias']==alias), None)
        if transform: dfm = apply_transform(dfm, transform)
        dfm = dfm[['date','value']].rename(columns={'value': alias}).dropna()
        frames.append(dfm.set_index('date'))
    feat = pd.concat(frames, axis=1).sort_index()
    # Drop rows with too many NaNs
    thresh = int(0.8*len(feat.columns))
    feat = feat.dropna(thresh=thresh).ffill()
    return feat

def demo():
    print("Features module ready.")

if __name__ == "__main__":
    import sys
    if "--demo" in sys.argv: demo()
