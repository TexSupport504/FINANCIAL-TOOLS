from __future__ import annotations
import pandas as pd, numpy as np

def position_size_kelly_lite(win_rate: float, avg_win: float, avg_loss: float, cap: float = 0.015) -> float:
    edge = win_rate*avg_win - (1-win_rate)*avg_loss
    var = (win_rate*(avg_win**2) + (1-win_rate)*(avg_loss**2)) - edge**2
    if var <= 0: return cap
    f = 0.5 * (edge / var)
    return float(max(0.0, min(cap, f)))
