from __future__ import annotations
import pandas as pd, numpy as np

PRIMES = [2,3,5,7]

def _nearest_prime(x: float) -> int:
    x = max(0, round(x))
    return min(PRIMES, key=lambda p: abs(p - x))

def discretize_z_series(s: pd.Series) -> pd.Series:
    return s.fillna(0).round().clip(-7,7).apply(lambda v: _nearest_prime(v if v>0 else 0))

def goldbach_pair_score(features_df: pd.DataFrame, corr_win_months: int = 36, lam: float = 1.0) -> pd.DataFrame:
    z = features_df.copy()
    disc = z.apply(discretize_z_series)
    # Rolling correlation by month window (approx: use period window on monthly index)
    corr = z.rolling(window=corr_win_months, min_periods=max(6, corr_win_months//3)).corr()
    out = []
    cols = list(z.columns)
    for i in range(len(cols)):
        for j in range(i+1, len(cols)):
            a, b = cols[i], cols[j]
            key = (a, b)
            # extract pairwise rolling corr for a vs b
            rho = corr.xs(a, level=1)[b].reindex(z.index).abs().fillna(0)
            score = disc[a] + disc[b] - lam*rho
            out.append(pd.DataFrame({"date": z.index, "pair": f"{a}+{b}", "score": score.values}))
    pairs = pd.concat(out).sort_values(["date","score"])
    best = pairs.groupby("date").tail(1).set_index("date")
    return best  # columns: pair, score

def regime_series(best_pairs: pd.DataFrame, thresh: float = 8.0) -> pd.Series:
    on = best_pairs["score"].rolling(2).min() >= thresh
    off = best_pairs["score"].rolling(2).max() <= (thresh-2)
    state = pd.Series(False, index=best_pairs.index)
    active = False
    for idx in best_pairs.index:
        if on.loc[idx]: active = True
        if off.loc[idx]: active = False
        state.loc[idx] = active
    return state.rename("risk_on")
