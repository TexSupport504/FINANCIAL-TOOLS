from __future__ import annotations
from pathlib import Path
import time
import pandas as pd
import httpx
import yaml

def _cache_path(cache_dir: str, series_id: str) -> Path:
    return Path(cache_dir).joinpath(f"{series_id}.csv")

def fetch_owid_csv(series_id: str) -> pd.DataFrame:
    url = f"https://ourworldindata.org/grapher/{series_id}.csv"
    with httpx.Client(timeout=30.0) as client:
        r = client.get(url)
        r.raise_for_status()
    df = pd.read_csv(pd.compat.StringIO(r.text))
    if 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'])
    elif 'year' in df.columns:
        df['date'] = pd.to_datetime(df['year'], format='%Y')
    else:
        raise ValueError("Expected 'date' or 'year' column in OWID CSV")
    # Standardize column names
    cols = {c: c.lower() for c in df.columns}
    df = df.rename(columns=cols)
    if 'entity' not in df.columns and 'country' in df.columns:
        df = df.rename(columns={'country': 'entity'})
    value_col = [c for c in df.columns if c not in ('date','entity','code','year')][-1]
    df = df[['date','entity', value_col]].rename(columns={value_col: 'value'})
    return df.sort_values('date').reset_index(drop=True)

def load_series(series_id: str, cache_dir: str) -> pd.DataFrame:
    path = _cache_path(cache_dir, series_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and (time.time() - path.stat().st_mtime) < 60*60*24:
        return pd.read_csv(path, parse_dates=['date'])
    df = fetch_owid_csv(series_id)
    df.to_csv(path, index=False)
    return df

def merge_series(config: dict, countries: list[str] | None = None) -> dict[str, pd.DataFrame]:
    out = {}
    cache_dir = config.get('cache_dir', 'data/raw')
    for item in config.get('series', []):
        sid = item['id']; alias = item['alias']
        df = load_series(sid, cache_dir)
        if countries:
            df = df[df['entity'].isin(countries)]
        out[alias] = df
    return out

def main_ping():
    print("DataGold sources module reachable.")

if __name__ == "__main__":
    import sys
    if "--ping" in sys.argv: main_ping()
