# AGENT_EXECUTION_STEPS.md

1) Unzip this folder inside the project repository root.
2) Read `README.md` and `datagold/config.yaml`.
3) Inventory existing Goldbach data in the repo. Record paths.
4) Ask clarifying questions only if required (use README ambiguity template).
5) Implement Phases 1–3 in README Task Plan.
6) Produce `REPORT.md` and `data/processed/metrics.json`.
7) Commit changes with message: "DataGold: integrate OWID + Goldbach regime and dashboard".
